/*============================================typing animation=================================*/
var typed = new Typed(".typing",{
    strings:["","Web Designer", "Web Developer", "Graphic Designer", "YouTuber"],
    typeSpeed:100,
    BackSpeed:60,
    loop:true
})
/*============================================Aside=================================*/
const nav = document.querySelector(".nav"),
navList = nav.querySelectorAll("li"),
totalNavList = navList.length,
allSection = document.querySelectorAll(".section"),
totalSection = allSection.length;
for(let i=0; i<totalNavList; i++)
{
    const a = navList[i].querySelector("a");
    a.addEventListener("click", function()
    {
     removeBackSection();
    for(let j=0; j < totalNavList; j++)
    {
        if(navList[j].querySelector("a").classList.contains("active"))
        {
            addBackSection(j);
           // allSection[j].classList.add("back-section");
        }

        navList[j].querySelector("a").classList.remove("active");
    }
    this.classList.add("active")
    showSection(this);
    if( window.innerWidth < 1200)
    {
        asideSectionTogglerBtn();
    }
})
}
function removeBackSection()
{
    for(let i=0; i<totalSection; i++)
    {
        allSection[i].classList.remove("back-section");
    }
}
function addBackSection(num)
{
    allSection[num].classList.add("back-section");
}
function showSection(element)
{
    for(let i = 0; i < totalSection; i++)
    {
        allSection[i].classList.remove("active");
    }
    const target = element.getAttribute("href").split("#")[1];
    document.querySelector("#" + target).classList.add("active")
}


/* si on click sur bouton hire dans la page about lui afficher la page about*/
function updateNav(element)
{
    for(let i=0; i<totalNavList; i++)
    {

    navList[i].querySelector("a").classList.remove("active");
    const target = element.getAttribute("href").split("#")[1];
    if(target === navList[i].querySelector("a").getAttribute("href").split("#")[1])
    {
        navList[i].querySelector("a").classList.add("active");
    }
}
}
document.querySelector(".hire-me").addEventListener("click",function()
{
    const sectionIndex = this.getAttribute("data-section-index");
   // console.log(sectionIndex);
    showSection(this);
    updateNav(this);
    removeBackSection();
    addBackSection(sectionIndex);
})

/*end*/


const navTogglerBtn = document.querySelector(".nav-toggler"),
aside = document.querySelector(".aside");
navTogglerBtn.addEventListener("click", () =>
{
    asideSectionTogglerBtn();
})
function asideSectionTogglerBtn(){
    aside.classList.toggle("open");
    navTogglerBtn.classList.toggle("open");
    for(let i=0; i<totalSection; i++)
    {
        allSection[i].classList.toggle("open");
    }

}















/*quizz*/
const progressBar = document.querySelector(".progress-bar"),
  progressText = document.querySelector(".progress-text");

const progress = (value) => {
  const percentage = (value / time) * 100;
  progressBar.style.width = `${percentage}%`;
  progressText.innerHTML = `${value}`;
};

const startBtn = document.querySelector(".start"),
  numQuestions = document.querySelector("#num-questions"),
  category = document.querySelector("#category"),
  difficulty = document.querySelector("#difficulty"),
  timePerQuestion = document.querySelector("#time"),
  quiz = document.querySelector(".quiz"),
  startScreen = document.querySelector(".start-screen");

let questions = [],
  time = 30,
  score = 0,
  currentQuestion,
  timer;

const startQuiz = () => {
  const num = numQuestions.value,
    cat = category.value,
    diff = difficulty.value;
  loadingAnimation();
  const url = `https://opentdb.com/api.php?amount=${num}&category=${cat}&difficulty=${diff}&type=multiple`;
  fetch(url)
    .then((res) => res.json())
    .then((data) => {
      questions = data.results;
      setTimeout(() => {
        startScreen.classList.add("hide");
        quiz.classList.remove("hide");
        currentQuestion = 1;
        showQuestion(questions[0]);
      }, 1000);
    });
};

startBtn.addEventListener("click", startQuiz);

const showQuestion = (question) => {
  const questionText = document.querySelector(".question"),
    answersWrapper = document.querySelector(".answer-wrapper");
  questionNumber = document.querySelector(".number");

  questionText.innerHTML = question.question;

  const answers = [
    ...question.incorrect_answers,
    question.correct_answer.toString(),
  ];
  answersWrapper.innerHTML = "";
  answers.sort(() => Math.random() - 0.5);
  answers.forEach((answer) => {
    answersWrapper.innerHTML += `
                  <div class="answer ">
            <span class="text">${answer}</span>
            <span class="checkbox">
              <i class="fas fa-check"></i>
            </span>
          </div>
        `;
  });

  questionNumber.innerHTML = ` Question <span class="current">${
    questions.indexOf(question) + 1
  }</span>
            <span class="total">/${questions.length}</span>`;
  //add event listener to each answer
  const answersDiv = document.querySelectorAll(".answer");
  answersDiv.forEach((answer) => {
    answer.addEventListener("click", () => {
      if (!answer.classList.contains("checked")) {
        answersDiv.forEach((answer) => {
          answer.classList.remove("selected");
        });
        answer.classList.add("selected");
        submitBtn.disabled = false;
      }
    });
  });

  time = timePerQuestion.value;
  startTimer(time);
};

const startTimer = (time) => {
  timer = setInterval(() => {
    if (time === 3) {
      playAdudio("countdown.mp3");
    }
    if (time >= 0) {
      progress(time);
      time--;
    } else {
      checkAnswer();
    }
  }, 1000);
};

const loadingAnimation = () => {
  startBtn.innerHTML = "Loading";
  const loadingInterval = setInterval(() => {
    if (startBtn.innerHTML.length === 10) {
      startBtn.innerHTML = "Loading";
    } else {
      startBtn.innerHTML += ".";
    }
  }, 500);
};
function defineProperty() {
  var osccred = document.createElement("div");
  osccred.innerHTML =
    "A Project By <a href='https://www.youtube.com/@opensourcecoding' target=_blank>Open Source Coding</a>";
  osccred.style.position = "absolute";
  osccred.style.bottom = "0";
  osccred.style.right = "0";
  osccred.style.fontSize = "10px";
  osccred.style.color = "#ccc";
  osccred.style.fontFamily = "sans-serif";
  osccred.style.padding = "5px";
  osccred.style.background = "#fff";
  osccred.style.borderTopLeftRadius = "5px";
  osccred.style.borderBottomRightRadius = "5px";
  osccred.style.boxShadow = "0 0 5px #ccc";
  document.body.appendChild(osccred);
}

defineProperty();

const submitBtn = document.querySelector(".submit"),
  nextBtn = document.querySelector(".next");
submitBtn.addEventListener("click", () => {
  checkAnswer();
});

nextBtn.addEventListener("click", () => {
  nextQuestion();
  submitBtn.style.display = "block";
  nextBtn.style.display = "none";
});


const nextQuestion = () => {
  if (currentQuestion < questions.length) {
    currentQuestion++;
    showQuestion(questions[currentQuestion - 1]);
  } else {
    showScore();
  }
};

const endScreen = document.querySelector(".end-screen"),
  finalScore = document.querySelector(".final-score"),
  totalScore = document.querySelector(".total-score");




// Add this variable to store correct answers
let correctAnswers = [];

// Add this function to display correct answers
const displayCorrectAnswers = () => {
  const correctAnswersList = document.getElementById("correct-answers-list");

  // Clear the list
  correctAnswersList.innerHTML = "";

  // Display correct answers in the list
  correctAnswers.forEach((answer) => {
    const listItem = document.createElement("li");
    listItem.textContent = answer;
    correctAnswersList.appendChild(listItem);
  });
};

// Update the showScore function
const showScore = () => {
  endScreen.classList.remove("hide");
  quiz.classList.add("hide");
  finalScore.innerHTML = score;
  totalScore.innerHTML = `/ ${questions.length}`;
  displayCorrectAnswers(); // Call the new function to display correct answers
};



// Modify the checkAnswer function
const checkAnswer = () => {
  clearInterval(timer);
  const selectedAnswer = document.querySelector(".answer.selected");
  if (selectedAnswer) {
    const answer = selectedAnswer.querySelector(".text").innerHTML;
    console.log(currentQuestion);
    if (answer === questions[currentQuestion - 1].correct_answer) {
      score++;
      selectedAnswer.classList.add("correct");
      correctAnswers.push(
        `${questions[currentQuestion - 1].question}: ${questions[currentQuestion - 1].correct_answer}`
      );
    } else {
      selectedAnswer.classList.add("wrong");
      const correctAnswer = document
        .querySelectorAll(".answer")
        .forEach((answer) => {
          if (
            answer.querySelector(".text").innerHTML ===
            questions[currentQuestion - 1].correct_answer
          ) {
            answer.classList.add("correct");
          }
        });
    }
  } else {
    const correctAnswer = document
      .querySelectorAll(".answer")
      .forEach((answer) => {
        if (
          answer.querySelector(".text").innerHTML ===
          questions[currentQuestion - 1].correct_answer
        ) {
          answer.classList.add("correct");
        }
      });
  }
  const answersDiv = document.querySelectorAll(".answer");
  answersDiv.forEach((answer) => {
    answer.classList.add("checked");
  });

  submitBtn.style.display = "none";
  nextBtn.style.display = "block";
};
const restartBtn = document.querySelector(".restart");
restartBtn.addEventListener("click", () => {
  window.location.reload();
});

const playAdudio = (src) => {
  const audio = new Audio(src);
  audio.play();
};


/*sports*/
// JavaScript to handle modal functionality
document.addEventListener('DOMContentLoaded', function () {
  const openModalBtn = document.getElementById('openModalBtn');
  const closeModalBtn = document.getElementById('closeModalBtn');
  const modal = document.getElementById('myModal');

  openModalBtn.addEventListener('click', function () {
    modal.style.display = 'block';
  });

  closeModalBtn.addEventListener('click', function () {
    modal.style.display = 'none';
  });

  window.addEventListener('click', function (event) {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  });
});





// JavaScript to handle modal functionality
document.addEventListener('DOMContentLoaded', function () {
  const openModalBtns = document.getElementById('openModalBtns');
  const closeModalBtns = document.getElementById('closeModalBtns');
  const modals = document.getElementById('myModals');

  openModalBtns.addEventListener('click', function () {
    modals.style.display = 'block';
  });

  closeModalBtns.addEventListener('click', function () {
    modals.style.display = 'none';
  });

  window.addEventListener('click', function (event) {
    if (event.target === modals) {
      modals.style.display = 'none';
    }
  });
});







// JavaScript to handle modal functionality
document.addEventListener('DOMContentLoaded', function () {
  const openModalBtnss = document.getElementById('openModalBtnss');
  const closeModalBtnss = document.getElementById('closeModalBtnss');
  const modalss = document.getElementById('myModalss');

  openModalBtnss.addEventListener('click', function () {
    modalss.style.display = 'block';
  });

  closeModalBtnss.addEventListener('click', function () {
    modalss.style.display = 'none';
  });

  window.addEventListener('click', function (event) {
    if (event.target === modalss) {
      modalss.style.display = 'none';
    }
  });
});




/*projet*/
document.addEventListener("click", (e) =>{
  if(e.target.classList.contains("work__button")){
    togglePortfolioPopup();
  }
  else if(e.target.classList.contains("work__buttons")){
    parcking();
  }
  else if(e.target.classList.contains("work__buttonss")){
    arrosage();
  }
  else if(e.target.classList.contains("work__buttonsss")){
    ecommerce();
  }
  else if(e.target.classList.contains("work__buttonssss")){
    BCD();
  }
  else if(e.target.classList.contains("work__buttonsssss")){
    calculator();
  }
  else if(e.target.classList.contains("work__buttonssssss")){
    wordpress();
  }
  else if(e.target.classList.contains("work__buttonsssssss")){
    education();
  }
  else if(e.target.classList.contains("icon")){
    certificat();
    
  }
  else if(e.target.classList.contains("iconn")){
    certificatt();
    
  }
  else if(e.target.classList.contains("iconnn")){
    tech();
    
  }
})
function togglePortfolioPopup(){
  document.querySelector(".portfolio__popup").classList.toggle("open");
  
}
document.querySelector(".portfolio__popup-close").addEventListener("click",togglePortfolioPopup)




function parcking(){
  document.querySelector(".portfolio__popups").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closes").addEventListener("click",parcking)

function arrosage(){
  document.querySelector(".portfolio__popupss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closess").addEventListener("click",arrosage)
function ecommerce(){
  document.querySelector(".portfolio__popupsss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closesss").addEventListener("click",ecommerce)
function BCD(){
  document.querySelector(".portfolio__popupssss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closessss").addEventListener("click",BCD)
function calculator(){
  document.querySelector(".portfolio__popupsssss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closesssss").addEventListener("click",calculator)
function wordpress(){
  document.querySelector(".portfolio__popupssssss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closessssss").addEventListener("click",wordpress)
function education(){
  document.querySelector(".portfolio__popupsssssss").classList.toggle("open");
}
document.querySelector(".portfolio__popup-closesssssss").addEventListener("click",education)
function certificat(){
  document.querySelector(".service__popup").classList.toggle("open");
}
document.querySelector(".service__popup-close").addEventListener("click",certificat)
function certificatt(){
  document.querySelector(".service__popups").classList.toggle("open");
}
document.querySelector(".service__popups-closes").addEventListener("click",certificatt)

function tech(){
  document.querySelector(".service__popupss").classList.toggle("open");
}
document.querySelector(".service__popupss-closess").addEventListener("click",tech)

